# Clearance — Setup

Welcome. You unzipped Clearance. Three steps to running it:

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # verify production build
```

## Push to a fresh GitHub repo

```bash
git init
git add .
git commit -m "Initial commit — Clearance debt dashboard"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

## Deploy to Vercel

1. Vercel dashboard → "Add New" → "Project"
2. Import the GitHub repo you just created
3. Framework auto-detects as Next.js — leave defaults
4. Click "Deploy"

Done. Pushes to `main` deploy automatically going forward.

## Architecture (so you know what you have)

**Clearance** is a personal debt tracking dashboard. Dark fintech-meets-fitness aesthetic. No backend — all state lives in `localStorage`. Architected so Plaid integration is a one-line provider swap when you're ready.

- `src/lib/types.ts` — `Debt`, `Payment`, `AppState` shapes.
- `src/lib/finance.ts` — compound-daily interest accrual, live balance, end-of-month projection, payoff-month formula. All pure functions.
- `src/lib/strategies.ts` — month-by-month forward simulation for avalanche and snowball, plus a comparison helper.
- `src/lib/providers/` — `manualDataProvider` writes to `localStorage`. `plaidDataProvider` ships as a marked stub. `index.ts` is the one-line switch.
- `src/hooks/useFinancialData.ts` — the only data API the UI ever touches.
- `src/hooks/useNow.ts` — re-renders every second so the live interest ticker updates in place.
- `src/components/` — all UI. `AppShell`, `DebtCard`, `StrategyPanel`, `PayoffChart` (hand-rolled SVG, no chart-lib dependency), `QuickUpdate`, `Sheet`, etc.
- `src/app/page.tsx` — composes everything.

## Switching to Plaid later

When you're ready: open `src/lib/providers/index.ts`, comment out `manualDataProvider`, uncomment `plaidDataProvider`. Then implement the marked TODOs in `plaidDataProvider.ts`. Nothing in the UI changes.

Built with Next.js 16, React 19, Tailwind CSS 4, TypeScript.
